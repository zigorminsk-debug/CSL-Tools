# Auto-launch CSL-Tools when pythonw.exe starts without args
import sys, os
# Only auto-launch if no script argument and exe name contains CSL-Tools
exe_name = os.path.basename(sys.executable).lower()
if 'csl-tools' in exe_name or 'pythonw' in exe_name:
    # Check if we're being run without script args (just exe)
    # If sys.argv has only exe, launch our app
    if len(sys.argv) == 1 or (len(sys.argv) > 1 and 'launch' not in sys.argv[0].lower()):
        try:
            # Prevent recursion
            if not os.environ.get('CSL_TOOLS_LAUNCHED'):
                os.environ['CSL_TOOLS_LAUNCHED'] = '1'
                # Add parent dir to path
                scriptdir = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) if 'pkgs' in __file__ else os.path.dirname(os.path.abspath(__file__))
                # Actually pkgs is in build/nsis/pkgs, but we are in portable root
                # Try to find main.py
                for p in [os.path.join(os.path.dirname(sys.executable), '..'), os.path.dirname(sys.executable), os.getcwd()]:
                    if os.path.exists(os.path.join(p, 'main.py')):
                        sys.path.insert(0, p)
                        break
                try:
                    import main
                    main.main()
                    sys.exit(0)
                except SystemExit:
                    raise
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    # Fallback to launch.pyw
                    try:
                        import CSL_Tools_launch
                    except:
                        pass
        except SystemExit:
            raise
        except Exception as e:
            print(f"sitecustomize error: {e}")
